<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/dang-nhap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dangNhap',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/cap-lai-mat-khau' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bkbR0nZtQb7TM8n3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/nguoi-dung' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nrlffdiYMQ68WA0I',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/ds-hocky' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_dsHocKy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/ds-nguoidung' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_dsNguoiDung',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/ds-khoanganhlop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_dsKhoaNganhLop',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/ds-sinhvien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_dsSinhVien',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/ds-giangvien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_dsGiangVien',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/tao-ds-taikhoan-sv' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_taoDsTaiKhoanSv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/admin/tao-ds-taikhoan-gv' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_taoDsTaiKhoanGv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/ds-hocky' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_dsHocKy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/dssv-tailen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_importDsSinhVien',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/ds-sinhvien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_dsSinhVien',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/dsgv-tailen' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_importDsGiangVien',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/ds-giangvien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_dsGiangVien',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/pdt/dang-bai' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_dangBai',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tbm/nganh' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tbm_layNganhCuaTBM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tbm/phan-cong-ngau-nhien' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tbm_phanCongNgauNhien',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/tbm/ds-phancong' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tbm_layDsPhanCongTheoTBM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/gv/ds-nhom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_layDsNhom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/gv/ds-sinhvien-pc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_layDsSinhVienPc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/gv/tao-nhom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_taoNhomDoAn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sv/thong-tin-sv' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sv_layThongTinSV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sv/ds-giangvien-hd' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sv_layDsGiangVienHd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sv/ds-nhom' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sv_layDsNhom',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/ds-thongbao' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layDsThongBao',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sxWPpY7aABUKtZxQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KTbuL1ew22pRuj2y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/(?|admin/(?|xoa\\-taikhoan\\-gv/([^/]++)(*:50)|khoa\\-taikhoan/([^/]++)(*:80)|mo\\-khoa\\-taikhoan/([^/]++)(*:114))|pdt/(?|xoa\\-bai/([^/]++)(*:147)|sua\\-bai/([^/]++)(*:172))|tbm/ds\\-(?|giangvien/([^/]++)(*:210)|sinhvien/([^/]++)(*:235))|gv/(?|nhom/(?|them\\-thanh\\-vien/([^/]++)(*:284)|xoa\\-thanh\\-vien/([^/]++)/([^/]++)(*:326))|xoa\\-nhom/([^/]++)(*:353))|nhom/chi\\-tiet/(?|([^/]++)(*:388)|tinnhan/(?|([^/]++)(*:415)|gui(*:426)))|ds\\-thongbao/chi\\-tiet/([^/]++)(*:467))|/storage/(.*)(*:489))/?$}sDu',
    ),
    3 => 
    array (
      50 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_xoaTaiKhoanGv',
          ),
          1 => 
          array (
            0 => 'id_giangvien',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      80 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_khoaTaiKhoan',
          ),
          1 => 
          array (
            0 => 'id_nguoidung',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      114 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ad_moKhoaTaiKhoan',
          ),
          1 => 
          array (
            0 => 'id_nguoidung',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_xoaBai',
          ),
          1 => 
          array (
            0 => 'id_baidang',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      172 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pdt_suaBai',
          ),
          1 => 
          array (
            0 => 'id_baidang',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      210 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tbm_dsGiangVienTheoNganh',
          ),
          1 => 
          array (
            0 => 'maNganh',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      235 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'tbm_dsSinhVienTheoNganh',
          ),
          1 => 
          array (
            0 => 'maNganh',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      284 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_themSinhVienVaoNhom',
          ),
          1 => 
          array (
            0 => 'idNhom',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      326 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_xoaThanhVienKhoiNhom',
          ),
          1 => 
          array (
            0 => 'id_nhom',
            1 => 'id_sinhvien',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'gv_xoaNhomDoAn',
          ),
          1 => 
          array (
            0 => 'id_nhom',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layChiTietNhom',
          ),
          1 => 
          array (
            0 => 'idNhom',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layTinNhanNhom',
          ),
          1 => 
          array (
            0 => 'idNhom',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'guiTinNhanNhom',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      467 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'layChiTietThongBao',
          ),
          1 => 
          array (
            0 => 'id_baidang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      489 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dangNhap' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/dang-nhap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TaiKhoanController@dangNhap',
        'controller' => 'App\\Http\\Controllers\\Api\\TaiKhoanController@dangNhap',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'dangNhap',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bkbR0nZtQb7TM8n3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/cap-lai-mat-khau',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TaiKhoanController@capLaiMatKhau',
        'controller' => 'App\\Http\\Controllers\\Api\\TaiKhoanController@capLaiMatKhau',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::bkbR0nZtQb7TM8n3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nrlffdiYMQ68WA0I' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nguoi-dung',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => '\\App\\Http\\Controllers\\Api\\TaiKhoanController@layNguoiDung',
        'controller' => '\\App\\Http\\Controllers\\Api\\TaiKhoanController@layNguoiDung',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::nrlffdiYMQ68WA0I',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_dsHocKy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/ds-hocky',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsHocKy',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsHocKy',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_dsHocKy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_dsNguoiDung' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/ds-nguoidung',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsNguoiDung',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsNguoiDung',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_dsNguoiDung',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_dsKhoaNganhLop' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/ds-khoanganhlop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsKhoaNganhLop',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsKhoaNganhLop',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_dsKhoaNganhLop',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_dsSinhVien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/ds-sinhvien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsSinhVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsSinhVien',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_dsSinhVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_dsGiangVien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/admin/ds-giangvien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsGiangVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsGiangVien',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_dsGiangVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_taoDsTaiKhoanSv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/tao-ds-taikhoan-sv',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@taoDsTaiKhoanSv',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@taoDsTaiKhoanSv',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_taoDsTaiKhoanSv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_taoDsTaiKhoanGv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/admin/tao-ds-taikhoan-gv',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@taoDsTaiKhoanGv',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@taoDsTaiKhoanGv',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_taoDsTaiKhoanGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_xoaTaiKhoanGv' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/admin/xoa-taikhoan-gv/{id_giangvien}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@xoaTkGiangVien',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@xoaTkGiangVien',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_xoaTaiKhoanGv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_khoaTaiKhoan' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/khoa-taikhoan/{id_nguoidung}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@khoaTaiKhoan',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@khoaTaiKhoan',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_khoaTaiKhoan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ad_moKhoaTaiKhoan' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/admin/mo-khoa-taikhoan/{id_nguoidung}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:AD',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminController@moKhoaTaiKhoan',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminController@moKhoaTaiKhoan',
        'namespace' => NULL,
        'prefix' => 'api/admin',
        'where' => 
        array (
        ),
        'as' => 'ad_moKhoaTaiKhoan',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_dsHocKy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdt/ds-hocky',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsHocKy',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsHocKy',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_dsHocKy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_importDsSinhVien' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pdt/dssv-tailen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DaoTaoController@importDsSinhVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DaoTaoController@importDsSinhVien',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_importDsSinhVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_dsSinhVien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdt/ds-sinhvien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsSinhVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsSinhVien',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_dsSinhVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_importDsGiangVien' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pdt/dsgv-tailen',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DaoTaoController@importDsGiangVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DaoTaoController@importDsGiangVien',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_importDsGiangVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_dsGiangVien' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/pdt/ds-giangvien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsGiangVien',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@dsGiangVien',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_dsGiangVien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_dangBai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pdt/dang-bai',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DaoTaoController@dangBai',
        'controller' => 'App\\Http\\Controllers\\Api\\DaoTaoController@dangBai',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_dangBai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_xoaBai' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/pdt/xoa-bai/{id_baidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DaoTaoController@xoaBaiDang',
        'controller' => 'App\\Http\\Controllers\\Api\\DaoTaoController@xoaBaiDang',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_xoaBai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pdt_suaBai' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/pdt/sua-bai/{id_baidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:PDT',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DaoTaoController@capNhatBaiDang',
        'controller' => 'App\\Http\\Controllers\\Api\\DaoTaoController@capNhatBaiDang',
        'namespace' => NULL,
        'prefix' => 'api/pdt',
        'where' => 
        array (
        ),
        'as' => 'pdt_suaBai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tbm_layNganhCuaTBM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tbm/nganh',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:TBM',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@layNganhCuaTBM',
        'controller' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@layNganhCuaTBM',
        'namespace' => NULL,
        'prefix' => 'api/tbm',
        'where' => 
        array (
        ),
        'as' => 'tbm_layNganhCuaTBM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tbm_dsGiangVienTheoNganh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tbm/ds-giangvien/{maNganh}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:TBM',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsGiangVienTheoNganh',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsGiangVienTheoNganh',
        'namespace' => NULL,
        'prefix' => 'api/tbm',
        'where' => 
        array (
        ),
        'as' => 'tbm_dsGiangVienTheoNganh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tbm_dsSinhVienTheoNganh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tbm/ds-sinhvien/{maNganh}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:TBM',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsSinhVienTheoNganh',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsSinhVienTheoNganh',
        'namespace' => NULL,
        'prefix' => 'api/tbm',
        'where' => 
        array (
        ),
        'as' => 'tbm_dsSinhVienTheoNganh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tbm_phanCongNgauNhien' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/tbm/phan-cong-ngau-nhien',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:TBM',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@phanCongNgauNhien',
        'controller' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@phanCongNgauNhien',
        'namespace' => NULL,
        'prefix' => 'api/tbm',
        'where' => 
        array (
        ),
        'as' => 'tbm_phanCongNgauNhien',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'tbm_layDsPhanCongTheoTBM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/tbm/ds-phancong',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:TBM',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@layDsPhanCongTheoTBM',
        'controller' => 'App\\Http\\Controllers\\Api\\TruongBoMonController@layDsPhanCongTheoTBM',
        'namespace' => NULL,
        'prefix' => 'api/tbm',
        'where' => 
        array (
        ),
        'as' => 'tbm_layDsPhanCongTheoTBM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_layDsNhom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/gv/ds-nhom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@layDanhSachNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@layDanhSachNhom',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_layDsNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_layDsSinhVienPc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/gv/ds-sinhvien-pc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@layDanhSachSinhVienPc',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@layDanhSachSinhVienPc',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_layDsSinhVienPc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_taoNhomDoAn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/gv/tao-nhom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@taoNhomDoAn',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@taoNhomDoAn',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_taoNhomDoAn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_themSinhVienVaoNhom' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/gv/nhom/them-thanh-vien/{idNhom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@themSinhVienVaoNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@themSinhVienVaoNhom',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_themSinhVienVaoNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_xoaThanhVienKhoiNhom' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/gv/nhom/xoa-thanh-vien/{id_nhom}/{id_sinhvien}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@xoaThanhVienKhoiNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@xoaThanhVienKhoiNhom',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_xoaThanhVienKhoiNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'gv_xoaNhomDoAn' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/gv/xoa-nhom/{id_nhom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:GV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\GiangVienController@xoaNhomDoAn',
        'controller' => 'App\\Http\\Controllers\\Api\\GiangVienController@xoaNhomDoAn',
        'namespace' => NULL,
        'prefix' => 'api/gv',
        'where' => 
        array (
        ),
        'as' => 'gv_xoaNhomDoAn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sv_layThongTinSV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sv/thong-tin-sv',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:SV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SinhVienController@layThongTinSV',
        'controller' => 'App\\Http\\Controllers\\Api\\SinhVienController@layThongTinSV',
        'namespace' => NULL,
        'prefix' => 'api/sv',
        'where' => 
        array (
        ),
        'as' => 'sv_layThongTinSV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sv_layDsGiangVienHd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sv/ds-giangvien-hd',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:SV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SinhVienController@layDanhSachGiangVienHd',
        'controller' => 'App\\Http\\Controllers\\Api\\SinhVienController@layDanhSachGiangVienHd',
        'namespace' => NULL,
        'prefix' => 'api/sv',
        'where' => 
        array (
        ),
        'as' => 'sv_layDsGiangVienHd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sv_layDsNhom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/sv/ds-nhom',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'kiem_tra_dang_nhap:SV',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\SinhVienController@layDanhSachNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\SinhVienController@layDanhSachNhom',
        'namespace' => NULL,
        'prefix' => 'api/sv',
        'where' => 
        array (
        ),
        'as' => 'sv_layDsNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'layChiTietNhom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nhom/chi-tiet/{idNhom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layChiTietNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layChiTietNhom',
        'namespace' => NULL,
        'prefix' => 'api/nhom',
        'where' => 
        array (
        ),
        'as' => 'layChiTietNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'layTinNhanNhom' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/nhom/chi-tiet/tinnhan/{idNhom}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layTinNhanNhom',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layTinNhanNhom',
        'namespace' => NULL,
        'prefix' => 'api/nhom',
        'where' => 
        array (
        ),
        'as' => 'layTinNhanNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'guiTinNhanNhom' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/nhom/chi-tiet/tinnhan/gui',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@guiTinNhan',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@guiTinNhan',
        'namespace' => NULL,
        'prefix' => 'api/nhom',
        'where' => 
        array (
        ),
        'as' => 'guiTinNhanNhom',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'layDsThongBao' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ds-thongbao',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsThongBao',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layDsThongBao',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'layDsThongBao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'layChiTietThongBao' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/ds-thongbao/chi-tiet/{id_baidang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DuLieuController@layChiTietThongBao',
        'controller' => 'App\\Http\\Controllers\\Api\\DuLieuController@layChiTietThongBao',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'layChiTietThongBao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sxWPpY7aABUKtZxQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:848:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'D:\\\\xampp\\\\htdocs\\\\doantn_2025\\\\backend_laravel\\\\vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Foundation\\\\Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"00000000000005340000000000000000";}}',
        'as' => 'generated::sxWPpY7aABUKtZxQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KTbuL1ew22pRuj2y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:46:"function () {
    // return view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000005600000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KTbuL1ew22pRuj2y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:63:"D:\\xampp\\htdocs\\doantn_2025\\backend_laravel\\storage\\app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:0;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000005620000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
