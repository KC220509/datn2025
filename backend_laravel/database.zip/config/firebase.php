<?php

return [
    'credentials' => env('FIREBASE_CREDENTIALS'), 
    'database_url' => env('FIREBASE_DATABASE_URL'), 
];